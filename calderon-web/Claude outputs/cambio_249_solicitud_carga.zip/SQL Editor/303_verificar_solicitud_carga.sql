-- =============================================================================
-- IronTrack — Verificación 303 · Cambio 249 (migración 259) · Solicitud de carga
-- -----------------------------------------------------------------------------
-- Correr DESPUÉS de la migración 259. NO GUARDA NADA: usa dos usuarios ZZ, un viaje en
-- curso y una estación con correo que ya existen, prueba todo y termina con un error a
-- propósito («VERIFICACIÓN 303 OK …») que deshace todo (no queda la orden, ni el mail, ni
-- los avisos).
-- Si termina con otro error, copiarlo y mandarlo.
-- =============================================================================
DO $do$
DECLARE
    v_pide bigint; v_autoriza bigint; v_otro bigint; v ops.viaje_chofer%ROWTYPE; v_est bigint; v_est_sin bigint;
    r jsonb; p tel.pedido_carga%ROWTYPE; o fue.orden_carga%ROWTYPE; x jsonb; v_err text; n int; v_ok text[] := '{}';
BEGIN
    IF coalesce((SELECT valor::text::int FROM ref.parametro WHERE codigo = 'web.version_base'), 0) < 259 THEN
        RAISE EXCEPTION 'Falta aplicar la migración 259';
    END IF;

    -- Un viaje en curso cuyo camión no tenga orden vigente ni solicitud pendiente
    SELECT vc.* INTO v FROM ops.viaje_chofer vc
     WHERE vc.estado = 'abierto' AND vc.eliminado_en IS NULL
       AND NOT EXISTS (SELECT 1 FROM fue.orden_carga oc WHERE oc.camion_id = vc.camion_id AND oc.genset_id IS NULL AND oc.estado IN ('emitida', 'autorizada') AND oc.vence_en > now())
       AND NOT EXISTS (SELECT 1 FROM tel.pedido_carga pc WHERE pc.camion_id = vc.camion_id AND pc.estado = 'pendiente')
     ORDER BY vc.salida_ts DESC LIMIT 1;
    IF v.id IS NULL THEN RAISE EXCEPTION 'No hay un viaje en curso libre para probar'; END IF;
    SELECT id INTO v_est FROM mae.estacion_servicio
     WHERE eliminado_en IS NULL AND NOT es_tanque_propio AND nullif(btrim(coalesce(correo, '')), '') IS NOT NULL ORDER BY id LIMIT 1;
    IF v_est IS NULL THEN RAISE EXCEPTION 'No hay una estación con correo para probar'; END IF;
    SELECT id INTO v_est_sin FROM mae.estacion_servicio
     WHERE eliminado_en IS NULL AND NOT es_tanque_propio AND nullif(btrim(coalesce(correo, '')), '') IS NULL ORDER BY id LIMIT 1;

    -- Usuarios ZZ: uno de Telemetría que pide, uno que autoriza, uno sin permisos
    INSERT INTO seg.usuario (login, nombre) VALUES ('zz_pide_303', 'ZZ Pide 303') RETURNING id INTO v_pide;
    INSERT INTO seg.usuario (login, nombre, autoriza_cargas) VALUES ('zz_autoriza_303', 'ZZ Autoriza 303', true) RETURNING id INTO v_autoriza;
    INSERT INTO seg.usuario (login, nombre) VALUES ('zz_otro_303', 'ZZ Otro 303') RETURNING id INTO v_otro;
    INSERT INTO seg.usuario_rol (usuario_id, rol_codigo) VALUES (v_pide, 'analista_control');
    INSERT INTO ops.push_suscripcion (usuario_id, endpoint, p256dh, auth) VALUES
        (v_pide, 'https://zz.invalid/303/pide', 'zz', 'zz'), (v_autoriza, 'https://zz.invalid/303/autoriza', 'zz', 'zz');

    -- 1 · Sin permiso no se pide
    PERFORM set_config('app.usuario_id', v_otro::text, true);
    BEGIN
        PERFORM tel.fn_pedir_carga(v.id, v_est, 100, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'sistema');
        RAISE EXCEPTION 'FALLA 1: alguien sin Telemetría pudo pedir';
    EXCEPTION WHEN insufficient_privilege THEN v_ok := v_ok || '1 sin permiso no pide'::text;
    END;

    PERFORM set_config('app.usuario_id', v_pide::text, true);
    -- 2 · Por sistema exige qué se carga
    BEGIN
        PERFORM tel.fn_pedir_carga(v.id, v_est, 100, p_via => 'sistema');
        RAISE EXCEPTION 'FALLA 2: se pidió por sistema sin decir qué se carga';
    EXCEPTION WHEN invalid_parameter_value THEN v_ok := v_ok || '2 exige qué se carga'::text;
    END;
    -- 3 · Vía inválida
    BEGIN
        PERFORM tel.fn_pedir_carga(v.id, v_est, 100, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'mail');
        RAISE EXCEPTION 'FALLA 3: aceptó una vía inválida';
    EXCEPTION WHEN invalid_parameter_value THEN v_ok := v_ok || '3 vía inválida'::text;
    END;
    -- 4 · Estación sin correo: por sistema no
    IF v_est_sin IS NOT NULL THEN
        BEGIN
            PERFORM tel.fn_pedir_carga(v.id, v_est_sin, 100, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'sistema');
            RAISE EXCEPTION 'FALLA 4: pidió por sistema en una estación sin correo';
        EXCEPTION WHEN invalid_parameter_value THEN v_ok := v_ok || '4 estación sin correo'::text;
        END;
    END IF;
    -- 5 · Los datos del formulario los puede leer quien pide
    x := fue.fn_preparar_orden_carga(v.camion_id, v_est);
    IF x ->> 'patente' IS NULL THEN RAISE EXCEPTION 'FALLA 5: no leyó los datos del formulario'; END IF;
    v_ok := v_ok || '5 formulario para quien pide'::text;

    -- 6 · Por mensaje sigue como antes (precio a mano por si la estación no tiene cargas) y con lo que se carga
    r := tel.fn_pedir_carga(v.id, v_est, 150, p_precio => 1000, p_detalle => '{"destino":"tanques","tanques":{"modo":"litros","litros":150}}', p_via => 'mensaje');
    SELECT * INTO p FROM tel.pedido_carga WHERE id = (r ->> 'id')::bigint;
    IF p.via <> 'mensaje' OR p.estado IS NOT NULL OR r ->> 'mensaje' NOT LIKE '%*A cargar:* Tanques: 150 L%' THEN
        RAISE EXCEPTION 'FALLA 6: el pedido por mensaje quedó mal: % / %', to_jsonb(p) - 'mensaje' - 'datos', r ->> 'mensaje';
    END IF;
    IF EXISTS (SELECT 1 FROM ops.push_saliente WHERE clave = 'pedido_carga:' || p.id) THEN RAISE EXCEPTION 'FALLA 6: el pedido por mensaje mandó aviso'; END IF;
    v_ok := v_ok || '6 por mensaje como antes'::text;

    -- 7 · Por sistema: pendiente y aviso a quien autoriza
    r := tel.fn_pedir_carga(v.id, v_est, 400, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'sistema', p_observacion => 'ZZ prueba 303');
    SELECT * INTO p FROM tel.pedido_carga WHERE id = (r ->> 'id')::bigint;
    IF p.estado <> 'pendiente' OR p.via <> 'sistema' OR p.detalle ->> 'destino' <> 'tanques' OR p.observacion <> 'ZZ prueba 303' THEN
        RAISE EXCEPTION 'FALLA 7: la solicitud quedó mal: %', to_jsonb(p) - 'mensaje' - 'datos';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM ops.push_saliente WHERE usuario_id = v_autoriza AND clave = 'pedido_carga:' || p.id AND url = '/combustible/cargas?vista=ordenes') THEN
        RAISE EXCEPTION 'FALLA 7: no se generó el aviso para quien autoriza';
    END IF;
    IF EXISTS (SELECT 1 FROM ops.push_saliente WHERE usuario_id = v_pide AND clave = 'pedido_carga:' || p.id) THEN
        RAISE EXCEPTION 'FALLA 7: le avisó a quien la pidió';
    END IF;
    v_ok := v_ok || '7 por sistema pendiente con aviso'::text;

    -- 8 · Otra para el mismo camión: no
    BEGIN
        PERFORM tel.fn_pedir_carga(v.id, v_est, 100, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'sistema');
        RAISE EXCEPTION 'FALLA 8: aceptó dos solicitudes pendientes del mismo camión';
    EXCEPTION WHEN unique_violation THEN v_ok := v_ok || '8 una pendiente por camión'::text;
    END;

    -- 9 · Se ve en Seguimiento como pendiente y en la lista de Órdenes de carga
    x := tel.fn_pedidos_carga_viaje(v.id);
    IF x -> 0 ->> 'estado' <> 'pendiente' OR x -> 0 ->> 'a_cargar' <> 'Tanques: llenos' THEN RAISE EXCEPTION 'FALLA 9: Seguimiento no la muestra pendiente: %', x -> 0; END IF;
    PERFORM set_config('app.usuario_id', v_autoriza::text, true);
    IF NOT EXISTS (SELECT 1 FROM jsonb_array_elements(fue.fn_solicitudes_carga()) e WHERE (e ->> 'id')::bigint = p.id) THEN
        RAISE EXCEPTION 'FALLA 9: no aparece en Órdenes de carga';
    END IF;
    v_ok := v_ok || '9 se ve en los dos lados'::text;

    -- 10 · Quien pide no puede aprobar ni rechazar
    PERFORM set_config('app.usuario_id', v_pide::text, true);
    BEGIN
        PERFORM fue.fn_aprobar_solicitud_carga(p.id);
        RAISE EXCEPTION 'FALLA 10: quien pide pudo aprobar';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        PERFORM fue.fn_rechazar_solicitud_carga(p.id, 'no corresponde');
        RAISE EXCEPTION 'FALLA 10: quien pide pudo rechazar';
    EXCEPTION WHEN insufficient_privilege THEN v_ok := v_ok || '10 solo aprueba quien autoriza'::text;
    END;

    -- 11 · Rechazar exige motivo
    PERFORM set_config('app.usuario_id', v_autoriza::text, true);
    BEGIN
        PERFORM fue.fn_rechazar_solicitud_carga(p.id, ' no ');
        RAISE EXCEPTION 'FALLA 11: rechazó sin motivo';
    EXCEPTION WHEN invalid_parameter_value THEN v_ok := v_ok || '11 rechazo exige motivo'::text;
    END;

    -- 12 · Aprobar con cambios (editar): genera la orden con lo editado, el mail y avisa a quien pidió
    r := fue.fn_aprobar_solicitud_carga(p.id, v_est, '{"destino":"tanques","tanques":{"modo":"litros","litros":250}}', NULL, 'ZZ editada 303');
    SELECT * INTO o FROM fue.orden_carga WHERE id = (r ->> 'id')::bigint;
    SELECT * INTO p FROM tel.pedido_carga WHERE id = p.id;
    IF o.id IS NULL OR o.camion_id <> v.camion_id OR o.estado <> 'emitida' OR (o.detalle #>> '{tanques,litros}')::numeric <> 250 OR o.observacion <> 'ZZ editada 303'
       OR o.creada_por <> v_autoriza OR o.mail_id IS NULL THEN
        RAISE EXCEPTION 'FALLA 12: la orden quedó mal: %', to_jsonb(o) - 'token' - 'palabra_hash';
    END IF;
    IF p.estado <> 'aprobada' OR p.orden_id <> o.id OR p.resuelto_por <> v_autoriza THEN RAISE EXCEPTION 'FALLA 12: la solicitud no quedó aprobada'; END IF;
    IF NOT EXISTS (SELECT 1 FROM ops.push_saliente WHERE usuario_id = v_pide AND clave = 'pedido_carga:' || p.id || ':aprobada' AND cuerpo LIKE '%' || o.numero || '%') THEN
        RAISE EXCEPTION 'FALLA 12: no le avisó a quien pidió';
    END IF;
    IF (r ->> 'palabra') IS NULL OR (r ->> 'editada')::boolean IS NOT TRUE THEN RAISE EXCEPTION 'FALLA 12: no devolvió la palabra: %', r; END IF;
    v_ok := v_ok || '12 aprobar con cambios'::text;

    -- 13 · No se aprueba ni se rechaza dos veces
    BEGIN
        PERFORM fue.fn_rechazar_solicitud_carga(p.id, 'ya no hace falta');
        RAISE EXCEPTION 'FALLA 13: rechazó una ya aprobada';
    EXCEPTION WHEN object_not_in_prerequisite_state THEN v_ok := v_ok || '13 no se resuelve dos veces'::text;
    END;

    -- 14 · Seguimiento la muestra aprobada con la orden
    PERFORM set_config('app.usuario_id', v_pide::text, true);
    x := tel.fn_pedidos_carga_viaje(v.id);
    IF x -> 0 ->> 'estado' <> 'aprobada' OR x -> 0 ->> 'orden' <> o.numero THEN RAISE EXCEPTION 'FALLA 14: Seguimiento no muestra la orden: %', x -> 0; END IF;
    v_ok := v_ok || '14 Seguimiento muestra la orden'::text;

    -- 15 · Con la orden vigente no se pide otra por sistema
    BEGIN
        PERFORM tel.fn_pedir_carga(v.id, v_est, 100, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'sistema');
        RAISE EXCEPTION 'FALLA 15: pidió con una orden vigente';
    EXCEPTION WHEN unique_violation THEN v_ok := v_ok || '15 no pide con orden vigente'::text;
    END;

    -- 16 · Rechazo: se anula la orden de la prueba, se pide otra y se rechaza
    PERFORM set_config('app.usuario_id', v_autoriza::text, true);
    PERFORM fue.fn_anular_orden_carga(o.id, 'ZZ prueba 303');
    PERFORM set_config('app.usuario_id', v_pide::text, true);
    r := tel.fn_pedir_carga(v.id, v_est, 300, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'sistema');
    PERFORM set_config('app.usuario_id', v_autoriza::text, true);
    PERFORM fue.fn_rechazar_solicitud_carga((r ->> 'id')::bigint, 'ZZ carga en la próxima estación');
    SELECT * INTO p FROM tel.pedido_carga WHERE id = (r ->> 'id')::bigint;
    IF p.estado <> 'rechazada' OR p.motivo_rechazo <> 'ZZ carga en la próxima estación' OR p.orden_id IS NOT NULL THEN RAISE EXCEPTION 'FALLA 16: el rechazo quedó mal'; END IF;
    IF NOT EXISTS (SELECT 1 FROM ops.push_saliente WHERE usuario_id = v_pide AND clave = 'pedido_carga:' || p.id || ':rechazada' AND cuerpo LIKE 'ZZ carga en la próxima estación%') THEN
        RAISE EXCEPTION 'FALLA 16: no le avisó el rechazo a quien pidió';
    END IF;
    v_ok := v_ok || '16 rechazo con motivo y aviso'::text;

    -- 17 · Aprobar sin cambios usa lo pedido
    PERFORM set_config('app.usuario_id', v_pide::text, true);
    r := tel.fn_pedir_carga(v.id, v_est, 300, p_detalle => '{"destino":"tanques","tanques":{"modo":"lleno"}}', p_via => 'sistema', p_observacion => 'ZZ sin cambios');
    PERFORM set_config('app.usuario_id', v_autoriza::text, true);
    r := fue.fn_aprobar_solicitud_carga((r ->> 'id')::bigint);
    SELECT * INTO o FROM fue.orden_carga WHERE id = (r ->> 'id')::bigint;
    IF o.estacion_id <> v_est OR o.detalle #>> '{tanques,modo}' <> 'lleno' OR o.observacion <> 'ZZ sin cambios' THEN RAISE EXCEPTION 'FALLA 17: la orden no usó lo pedido'; END IF;
    v_ok := v_ok || '17 aprobar sin cambios'::text;

    -- 18 · La lista de Seguimiento trae el estado
    x := tel.fn_seguimiento_viajes();
    IF EXISTS (SELECT 1 FROM jsonb_array_elements(x) e WHERE (e ->> 'viaje_id')::bigint = v.id)
       AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements(x) e WHERE (e ->> 'viaje_id')::bigint = v.id AND e #>> '{solicitud_carga,estado}' = 'aprobada') THEN
        RAISE EXCEPTION 'FALLA 18: la lista de Seguimiento no trae la solicitud';
    END IF;
    v_ok := v_ok || '18 lista de Seguimiento'::text;

    RAISE EXCEPTION 'VERIFICACIÓN 303 OK (no se guardó nada): %', array_to_string(v_ok, ' · ');
END $do$;
