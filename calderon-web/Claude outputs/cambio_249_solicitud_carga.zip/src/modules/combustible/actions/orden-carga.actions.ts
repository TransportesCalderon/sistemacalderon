'use server';

import { z } from 'zod';
import { createAction } from '@/server/actions/create-action';
import { iaRepository } from '@/modules/ia/ia.repository';
import { ordenCargaRepository } from '../repositories/orden-carga.repository';

/**
 * Migración 234 · Órdenes de carga de combustible. La base decide quién puede (Gerencia genera y anula; el chofer
 * termina la suya) y valida todo; acá solo se revisa la forma de los datos.
 */
const id = z.number().int().positive();
/** Migración 248: solo tanques o tanques y mochila (la base valida y calcula). */
const detalleOrden = z.object({
  destino: z.enum(['tanques', 'tanques_mochila']),
  tanques: z.object({ modo: z.enum(['lleno', 'litros']), litros: z.number().finite().nullable().optional() }),
  mochila: z.object({ modo: z.enum(['llena', 'litros']), litros: z.number().finite().nullable().optional() }).optional(),
});

export const crearOrdenCarga = createAction({
  // Migración 247: lo decide la marca «Autoriza cargas» de cada usuario (lo controla la base)
  permiso: ['combustible.ordenes:editar', 'combustible.cargas:ver'],
  schema: z.object({
    camionId: id.nullable(),
    estacionId: id.nullable(),
    modo: z.enum(['litros', 'importe', 'llenar']),
    litros: z.number().finite().nullable(),
    importe: z.number().finite().nullable(),
    moneda: z.string().max(5).nullable(),
    choferId: id.nullable(),
    observacion: z.string().max(500).nullable(),
    detalle: detalleOrden.nullable().optional(),
  }),
  handler: (d, { db }) => ordenCargaRepository(db).crear(d),
});

/**
 * Migración 259: aprobar una solicitud de carga de Seguimiento (genera la orden y el mail a la estación).
 * Con `cambios` (Editar) se aprueba lo que quedó en el formulario. Lo decide la marca «Autoriza cargas» (la base).
 */
export const aprobarSolicitudCarga = createAction({
  permiso: ['combustible.ordenes:editar', 'combustible.cargas:ver'],
  schema: z.object({
    id,
    cambios: z
      .object({
        estacionId: id.nullable(),
        detalle: detalleOrden.nullable(),
        choferId: id.nullable(),
        observacion: z.string().max(500).nullable(),
      })
      .nullable()
      .optional(),
  }),
  handler: (d, { db }) => ordenCargaRepository(db).aprobarSolicitud(d.id, d.cambios ?? null),
});

/** Migración 259: rechazar una solicitud de carga (la base exige el motivo y le avisa a quien la pidió). */
export const rechazarSolicitudCarga = createAction({
  permiso: ['combustible.ordenes:editar', 'combustible.cargas:ver'],
  schema: z.object({ id, motivo: z.string().max(500) }),
  handler: (d, { db }) => ordenCargaRepository(db).rechazarSolicitud(d.id, d.motivo),
});

/** Migración 253: registrar la carga de una orden terminada (con «inicia viaje» y lo que se corrigió). */
export const registrarCargaOrden = createAction({
  permiso: 'combustible.cargas:editar',
  schema: z.object({
    ordenId: id,
    iniciaViaje: z.boolean(),
    ajustes: z.object({
      litros: z.number().finite().positive().nullable().optional(),
      precio_unitario: z.number().finite().min(0).nullable().optional(),
      odometro_km: z.number().finite().min(0).nullable().optional(),
      ticket_numero: z.string().max(60).nullable().optional(),
      tanque_lleno: z.boolean().optional(),
      faltante_lleno_l: z.number().finite().min(0).nullable().optional(),
      faltante_observacion: z.string().max(500).nullable().optional(),
    }),
  }),
  handler: (d, { db }) => ordenCargaRepository(db).registrarCarga(d.ordenId, d.iniciaViaje, d.ajustes),
});

/** Migración 252: orden de carga para un genset (aparte de la del camión). */
export const crearOrdenGenset = createAction({
  permiso: ['combustible.ordenes:editar', 'combustible.cargas:ver'],
  schema: z.object({
    gensetId: id,
    estacionId: id.nullable(),
    modo: z.enum(['lleno', 'litros']),
    litros: z.number().finite().nullable(),
    choferId: id.nullable(),
    observacion: z.string().max(500).nullable(),
  }),
  handler: (d, { db }) => ordenCargaRepository(db).crearGenset(d),
});

export const anularOrdenCarga = createAction({
  permiso: ['combustible.ordenes:editar', 'combustible.cargas:ver'],
  schema: z.object({ id, motivo: z.string().max(500) }),
  handler: (d, { db }) => ordenCargaRepository(db).anular(d.id, d.motivo),
});

export const revisarOrdenCarga = createAction({
  permiso: 'combustible.ordenes:ver',
  schema: z.object({ id }),
  handler: (d, { db }) => ordenCargaRepository(db).revisar(d.id),
});

export const guardarCorreoEstacion = createAction({
  permiso: ['combustible.ordenes:ver', 'combustible.cargas:ver'],
  schema: z.object({ estacionId: id, correo: z.string().max(500) }),
  handler: (d, { db }) => ordenCargaRepository(db).correoEstacion(d.estacionId, d.correo),
});

// El chofer
export const terminarOrdenCarga = createAction({
  permiso: 'chofer.mi_carga:editar',
  schema: z.object({
    id,
    fotos: z.array(z.object({ ruta: z.string().min(1).max(300), hash: z.string().max(100) })).min(1).max(5),
    lecturas: z.array(id).max(5),
    litros: z.number().finite().positive().nullable(),
    /** Migración 252: horómetro del genset (solo en órdenes de genset; la base lo exige). */
    horometro: z.number().finite().min(0).nullable().optional(),
  }),
  handler: (d, { db }) => ordenCargaRepository(db).terminar(d.id, d.fotos, d.lecturas, d.litros, d.horometro ?? null),
});

export const leerTicketChofer = createAction({
  permiso: 'chofer.mi_carga:editar',
  schema: z.object({
    base64: z.string().min(16).max(6_000_000).regex(/^[A-Za-z0-9+/=]+$/, 'No llegó la foto.'),
    mediaType: z.enum(['image/jpeg', 'image/png', 'image/webp'], 'La IA lee fotos JPG, PNG o WEBP.'),
  }),
  handler: (d, { db }) => iaRepository(db).leer('ticket_combustible', d.base64, d.mediaType),
});

// Migración 236: conectar la cuenta de mail (Hotmail) y probar el envío. La base exige TI o Gerencia.
export const urlPermisoMail = createAction({
  permiso: 'combustible.ordenes:editar',
  schema: z.object({ volver: z.string().url().max(300) }),
  handler: (d, { db }) => ordenCargaRepository(db).urlPermisoMail(d.volver),
});

export const probarMail = createAction({
  permiso: 'combustible.ordenes:editar',
  schema: z.object({}),
  handler: (_d, { db }) => ordenCargaRepository(db).probarMail(),
});
